# Profilumfang

Im Starterprofil sind nur diese nutzerneutralen Kodi-Dateien enthalten:

- `userdata/favourites.xml`: deutsche Schnellzugriffe auf Filme, Serien, Musik, Dateimanager und Einstellungen.
- `userdata/sources.xml`: lokale Ordner für Filme, Musik, Bilder und Downloads.

Der mitgelieferte Kodi-Script-Installer legt vor dem Überschreiben eine Sicherung unter
`special://userdata/KODi.Debil-Backups/<Zeitstempel>/` an.

Nicht enthalten: xStream, Cookies, HTML-Cache, Add-on-Datenbanken, persönliche Logins,
IPTV-/EPG-Listen oder fremde Add-on-Pakete.

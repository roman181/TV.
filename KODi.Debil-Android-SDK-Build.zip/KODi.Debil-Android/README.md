# KODi.Debil Android – Variante 1

**Offizielle Kodi-APK + KODi.Debil-Profil + separate Dashboard-APK**

Dieses Repository baut kein eigenes Kodi-Fork. Kodi bleibt die unveränderte offizielle Android-App von Kodi; KODi.Debil liefert ein separates Android-Dashboard und ein importierbares Starterprofil.

## Was enthalten ist?

- **Kodi 21.3 Omega**: GitHub Actions lädt die offizielle Kodi-APK für ARM64 und ARMv7 direkt vom offiziellen Kodi-Mirror.
- **KODi.Debil-Dashboard.apk**: eigenständige Android-App mit „Kodi starten“, Download-Link und Export für die Profilpakete.
- **KODi.Debil-Profil.zip**: neutrale Favoriten- und Medienquellen-Konfiguration.
- **Kodi-Profil-Installer**: kleines Kodi-Script-Add-on. Es installiert das Profil innerhalb von Kodi über `special://userdata/` und sichert vorhandene gleichnamige Dateien vor dem Ersetzen.

## Build ohne PC über GitHub Actions

1. Ein privates GitHub-Repository `KODi.Debil-Android` erstellen.
2. Alle Dateien und Ordner aus diesem Projekt hochladen und committen.
3. GitHub → Actions öffnen.
4. `KODi.Debil Android – Dashboard + Profil` starten. Das erzeugt Dashboard-APK und Profil-ZIPs.
5. Für das Gesamtpaket `KODi.Debil Android – Komplettpaket` → `Run workflow` wählen. Das Ergebnis enthält die offizielle Kodi-APK, Dashboard-APK, Profil-ZIPs und SHA256-Prüfsummen.
6. Für ein GitHub Release einen Tag wie `v1.0.0` erstellen oder die Release-Workflow-Datei mit einem Tag starten.

## Projektstruktur

```text
KODi.Debil-Android/
├── .github/workflows/
│   ├── build-dashboard.yml
│   └── release-bundle.yml
├── config/kodi-version.env
├── dashboard-app/             # separate Android-Dashboard-App
├── kodi/
│   ├── addons/script.kodidebil.setup/
│   ├── installer/
│   └── profile/userdata/
├── integrations/the-crew/     # optionale Metadaten-Referenz, nicht installiert
├── scripts/
└── README.md
```

## Wichtige Sicherheitshinweise

- Das frühere private Kombipaket enthält xStream-Cookies und Cache-Daten. Es wird **nicht** in dieses GitHub-Projekt kopiert und darf nicht öffentlich hochgeladen werden.
- Keine Cookies, Tokens, Passwörter, Datenbanken, Cache- oder persönlichen Sitzungsdateien in `kodi/profile/` ablegen. Der Workflow prüft das vor dem Paketieren.
- Das Profil installiert keine Drittanbieter-Add-ons und keine Streams. Externe Quellen nur verwenden, wenn Herkunft, Sicherheit und Nutzungsrechte geklärt sind.
- Das THE-CREW-Manifest liegt nur als optionale Referenz unter `integrations/the-crew/`; es wird weder in den Profil-Installer kopiert noch automatisch aktiviert.
- Die Dashboard-App verändert keine Kodi-Privatdaten. Die Profilübertragung erfolgt über ein Kodi-Script-Add-on, da Android den direkten Zugriff auf `Android/data` beschränkt.
- Die erzeugte Dashboard-Debug-APK ist für private Installation und Tests geeignet. Für öffentliche Verteilung sollte eine eigene Release-Signatur eingerichtet werden.

## Versionsbasis

- Kodi-Ziel: **21.3 Omega**
- Dashboard: Android, minSdk 24, compileSdk 36
- Java: 17
- Android Gradle Plugin: 8.13.0
- Kotlin Gradle Plugin: 2.3.0
- Gradle in GitHub Actions: 8.13

## Offizielle und technische Referenzen

- Kodi Android Downloads: https://kodi.tv/download/android/
- Kodi Android userdata path: https://kodi.wiki/view/Kodi_data_folder
- Kodi Userdata reference: https://kodi.wiki/view/Userdata
- Android Gradle Plugin compatibility: https://developer.android.com/build/releases/about-agp


## Vollständiger Android-Build ohne PC

Die GitHub-Actions installieren JDK 17, Android SDK Platform 36, Build Tools 36.0.0, Platform Tools und Gradle 8.13 automatisch. Siehe [SDK-SETUP.md](SDK-SETUP.md) und [README-SDK-ANDROID.md](README-SDK-ANDROID.md). Das SDK wird nicht ins Repository eingecheckt.

# KODi.Debil – vollständiger Android-Build

Die GitHub Actions richten JDK, Android SDK, Platform Tools, Build Tools und Gradle bei jedem Build ein. Du musst keine SDK-Dateien manuell hochladen und brauchst keinen PC.

## APK bauen

1. Repository `KODi.Debil-Android` auf GitHub hochladen.
2. Registerkarte **Actions** öffnen.
3. Workflow **KODi.Debil Android – Dashboard + Profil** auswählen.
4. **Run workflow** starten.
5. Nach erfolgreichem Lauf unter **Artifacts** `KODi.Debil-Android-APK-und-Profil` öffnen und herunterladen.

Enthalten sind `KODi.Debil-Dashboard-debug.apk`, Profil-ZIP, Kodi-Installer-ZIP und SHA256-Prüfsummen.

## Vollständiges Paket

Den Workflow **KODi.Debil Android – Komplettpaket** starten. Er baut die Dashboard-APK, lädt die offiziellen Kodi 21.3 Omega APK-Dateien für ARM64 und ARMv7 herunter und erzeugt ein ZIP-Paket. Mit einem Tag wie `v1.0.0` wird zusätzlich ein GitHub Release veröffentlicht.

Siehe `SDK-SETUP.md` für lokale Builds und Signierung.

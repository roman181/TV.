# Changelog

## 1.0.0
- Initial Android variant 1 project.
- Official Kodi 21.3 Omega APKs downloaded by CI for ARM64 and ARMv7.
- Separate KODi.Debil Android dashboard.
- Profile ZIP plus Kodi-native installer add-on with backup of overwritten files.
- Validation that blocks common credential, cookie, cache and database artifacts.

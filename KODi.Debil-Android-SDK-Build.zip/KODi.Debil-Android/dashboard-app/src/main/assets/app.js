(function () {
  "use strict";
  const status = document.getElementById("status");

  function bridgeCall(method) {
    if (!window.Android || typeof window.Android[method] !== "function") {
      alert("Diese Funktion ist nur in der KODi.Debil-Android-App verfügbar.");
      return;
    }
    window.Android[method]();
  }

  window.openKodi = () => bridgeCall("openKodi");
  window.openKodiDownload = () => bridgeCall("openKodiDownloadPage");
  window.exportProfile = () => bridgeCall("exportProfile");
  window.exportInstaller = () => bridgeCall("exportKodiInstaller");

  try {
    const installed = !!(window.Android && window.Android.isKodiInstalled());
    status.innerHTML = installed ? "<i></i> KODI INSTALLIERT" : "<i></i> KODI NOCH NICHT INSTALLIERT";
  } catch (_error) {
    status.innerHTML = "<i></i> BEREIT";
  }
})();

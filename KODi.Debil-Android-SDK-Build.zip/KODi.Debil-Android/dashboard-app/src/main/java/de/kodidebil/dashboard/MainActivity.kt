package de.kodidebil.dashboard

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var pendingAssetName: String? = null
    private val createDocumentRequest = 4107

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = false
            allowFileAccess = true
            allowContentAccess = false
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
        }
        webView.addJavascriptInterface(DashboardBridge(), "Android")
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                return when (uri.scheme?.lowercase()) {
                    "file" -> false
                    "https" -> {
                        openExternal(uri)
                        true
                    }
                    else -> true
                }
            }
        }
        webView.loadUrl("file:///android_asset/index.html")
    }

    private inner class DashboardBridge {
        @JavascriptInterface
        fun openKodi() {
            runOnUiThread {
                val launchIntent = packageManager.getLaunchIntentForPackage("org.xbmc.kodi")
                if (launchIntent != null) {
                    startActivity(launchIntent)
                } else {
                    Toast.makeText(this@MainActivity, "Kodi ist noch nicht installiert. Öffne die offizielle Downloadseite.", Toast.LENGTH_LONG).show()
                    openExternal(Uri.parse("https://kodi.tv/download/android/"))
                }
            }
        }

        @JavascriptInterface
        fun isKodiInstalled(): Boolean = packageManager.getLaunchIntentForPackage("org.xbmc.kodi") != null

        @JavascriptInterface
        fun openKodiDownloadPage() {
            runOnUiThread { openExternal(Uri.parse("https://kodi.tv/download/android/")) }
        }

        @JavascriptInterface
        fun exportProfile() {
            requestAssetExport("kodidebil-profile.zip", "KODi.Debil-Profil.zip")
        }

        @JavascriptInterface
        fun exportKodiInstaller() {
            requestAssetExport("kodidebil-installer.zip", "script.kodidebil.setup-1.0.0.zip")
        }
    }

    private fun requestAssetExport(assetName: String, suggestedName: String) {
        runOnUiThread {
            pendingAssetName = assetName
            val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "application/zip"
                putExtra(Intent.EXTRA_TITLE, suggestedName)
            }
            try {
                startActivityForResult(intent, createDocumentRequest)
            } catch (exception: Exception) {
                pendingAssetName = null
                Toast.makeText(this, "Speichern nicht verfügbar: ${exception.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        }
    }

    @Deprecated("Handled for the system file picker result")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != createDocumentRequest) return

        val assetName = pendingAssetName
        pendingAssetName = null
        if (resultCode != RESULT_OK || assetName == null) return
        val target: Uri = data?.data ?: return

        try {
            val output = contentResolver.openOutputStream(target)
                ?: throw IllegalStateException("Datei konnte nicht geöffnet werden")
            assets.open(assetName).use { input ->
                output.use { stream -> input.copyTo(stream) }
            }
            Toast.makeText(this, "ZIP-Datei wurde gespeichert.", Toast.LENGTH_LONG).show()
        } catch (exception: Exception) {
            Toast.makeText(this, "Export fehlgeschlagen: ${exception.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }

    private fun openExternal(uri: Uri) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (_: Exception) {
            Toast.makeText(this, "Kein Browser zum Öffnen gefunden.", Toast.LENGTH_SHORT).show()
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) {
            webView.removeJavascriptInterface("Android")
            webView.destroy()
        }
        super.onDestroy()
    }
}

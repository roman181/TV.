# Sicherheitsrichtlinie

Bitte keine Zugangsdaten, API-Schlüssel, Cookies, Session-Dateien, Datenbanken, Cache-Verzeichnisse oder privaten Kodi-Backups in dieses Repository committen.

Das frühere private KODi.Debil-Kombipaket ist nicht für öffentliche Veröffentlichung geeignet, solange darin xStream-Cookies oder andere Sitzungsdaten enthalten sind.

Melde Sicherheitsprobleme bitte nicht mit privaten Tokens oder vollständigen Logdateien in öffentlichen Issues.

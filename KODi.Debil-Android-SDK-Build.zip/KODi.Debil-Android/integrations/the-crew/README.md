# THE CREW – optionale Repository-Metadaten

Diese Integration ist nur als Referenz gedacht. Sie wird nicht vom Standardprofil installiert,
nicht vom Dashboard aktiviert und nicht in das Standard-Profilpaket aufgenommen.

Vor einer Nutzung müssen Quell-URLs, Kodi-21-Kompatibilität, Sicherheit, Lizenzen und
Nutzungsrechte eigenständig geprüft werden. Es werden keine Add-on-Pakete oder Medien gespiegelt.

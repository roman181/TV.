#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PROFILE_ROOT="${1:-$ROOT_DIR/kodi/profile}"
ADDON_XML="$ROOT_DIR/kodi/addons/script.kodidebil.setup/addon.xml"

if [[ ! -d "$PROFILE_ROOT/userdata" ]]; then
  echo "FEHLER: Profilordner fehlt: $PROFILE_ROOT/userdata" >&2
  exit 1
fi

BAD_FILES=$(find "$PROFILE_ROOT" -type f \( \
  -iname '*cookie*' -o -iname '*token*' -o -iname '*session*' -o \
  -iname '*password*' -o -iname '*credential*' -o -iname '*.db' -o \
  -iname '*.sqlite*' -o -iname '*.log' -o -iname '*.pem' -o \
  -iname '*.p12' -o -iname '*.jks' -o -iname '*.keystore' \
\) -print)
if [[ -n "$BAD_FILES" ]]; then
  echo "FEHLER: Private Sitzungs-/Datenbankdateien gefunden:" >&2
  echo "$BAD_FILES" >&2
  exit 2
fi

BAD_DIRS=$(find "$PROFILE_ROOT" -type d \( \
  -iname 'cookies' -o -iname 'cache' -o -iname 'htmlcache' -o \
  -iname 'temp' -o -iname 'thumbnails' -o -iname 'database' \
\) -print)
if [[ -n "$BAD_DIRS" ]]; then
  echo "FEHLER: Cache-/Datenbankordner gefunden:" >&2
  echo "$BAD_DIRS" >&2
  exit 3
fi

python3 - "$PROFILE_ROOT" "$ADDON_XML" <<'PY'
import pathlib, sys, xml.etree.ElementTree as ET
profile = pathlib.Path(sys.argv[1])
addon_xml = pathlib.Path(sys.argv[2])
xml_files = list(profile.rglob("*.xml")) + [addon_xml]
for path in xml_files:
    ET.parse(path)
required = [profile / "userdata" / "favourites.xml", profile / "userdata" / "sources.xml"]
missing = [str(p) for p in required if not p.is_file()]
if missing:
    raise SystemExit("Required profile file missing: " + ", ".join(missing))
print("XML validation passed for", len(xml_files), "file(s).")
PY

echo "Profilprüfung bestanden: keine erkannten privaten Cookies, Tokens, Cache- oder Datenbankdateien."

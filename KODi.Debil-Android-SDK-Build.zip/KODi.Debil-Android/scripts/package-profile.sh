#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PROFILE_DIR="$ROOT_DIR/kodi/profile"
ADDON_DIR="$ROOT_DIR/kodi/addons/script.kodidebil.setup"
DIST_DIR="$ROOT_DIR/dist"
ASSETS_DIR="$ROOT_DIR/dashboard-app/src/main/assets"
ADDON_VERSION="1.0.0"

bash "$ROOT_DIR/scripts/validate-profile.sh" "$PROFILE_DIR"
mkdir -p "$DIST_DIR" "$ASSETS_DIR" "$ADDON_DIR/resources/profile"
rm -rf "$ADDON_DIR/resources/profile/userdata"
cp -a "$PROFILE_DIR/userdata" "$ADDON_DIR/resources/profile/userdata"

rm -f "$DIST_DIR/KODi.Debil-Profil.zip" "$DIST_DIR/script.kodidebil.setup-${ADDON_VERSION}.zip"
(cd "$PROFILE_DIR" && zip -qr "$DIST_DIR/KODi.Debil-Profil.zip" README.txt userdata)
(cd "$ROOT_DIR/kodi/addons" && zip -qr "$DIST_DIR/script.kodidebil.setup-${ADDON_VERSION}.zip" "script.kodidebil.setup")

cp "$DIST_DIR/KODi.Debil-Profil.zip" "$ASSETS_DIR/kodidebil-profile.zip"
cp "$DIST_DIR/script.kodidebil.setup-${ADDON_VERSION}.zip" "$ASSETS_DIR/kodidebil-installer.zip"

(cd "$DIST_DIR" && sha256sum KODi.Debil-Profil.zip "script.kodidebil.setup-${ADDON_VERSION}.zip" > SHA256SUMS.txt)
echo "Profil und Kodi-Installer wurden gebaut: $DIST_DIR"

#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
VERSION="${1:-1.0.0}"
DIST_DIR="$ROOT_DIR/dist"
STAGE="$DIST_DIR/KODi.Debil-Android-Bundle"

required=(
  "$DIST_DIR/kodi/kodi-21.3-Omega-arm64-v8a.apk"
  "$DIST_DIR/kodi/kodi-21.3-Omega-armeabi-v7a.apk"
  "$DIST_DIR/KODi.Debil-Dashboard.apk"
  "$DIST_DIR/KODi.Debil-Profil.zip"
  "$DIST_DIR/script.kodidebil.setup-1.0.0.zip"
)
for file in "${required[@]}"; do
  if [[ ! -s "$file" ]]; then
    echo "Fehlendes Release-Artefakt: $file" >&2
    exit 10
  fi
done

rm -rf "$STAGE"
mkdir -p "$STAGE/01-Kodi" "$STAGE/02-Dashboard" "$STAGE/03-Profil"
cp "$DIST_DIR/kodi/kodi-21.3-Omega-arm64-v8a.apk" "$STAGE/01-Kodi/"
cp "$DIST_DIR/kodi/kodi-21.3-Omega-armeabi-v7a.apk" "$STAGE/01-Kodi/"
cp "$DIST_DIR/KODi.Debil-Dashboard.apk" "$STAGE/02-Dashboard/"
cp "$DIST_DIR/KODi.Debil-Profil.zip" "$STAGE/03-Profil/"
cp "$DIST_DIR/script.kodidebil.setup-1.0.0.zip" "$STAGE/03-Profil/"
cp "$ROOT_DIR/README-INSTALLATION.md" "$STAGE/"
cp "$ROOT_DIR/kodi/installer/ANDROID-INSTALL.md" "$STAGE/"
cat > "$STAGE/BUILD-INFO.txt" <<INFO
KODi.Debil Android Bundle $VERSION
Kodi: official Kodi 21.3 Omega Android packages
Dashboard: KODi.Debil standalone Android app (debug-signed build)
Profile: starter favourites and local source configuration
Installer: Kodi Python script add-on; overwriting files are backed up first
INFO

(
  cd "$STAGE"
  find . -type f ! -name SHA256SUMS.txt -print0 | sort -z | xargs -0 sha256sum > SHA256SUMS.txt
)
(cd "$DIST_DIR" && zip -qr "KODi.Debil-Android-Bundle-v${VERSION}.zip" "KODi.Debil-Android-Bundle")
echo "$DIST_DIR/KODi.Debil-Android-Bundle-v${VERSION}.zip"

# KODi.Debil – Kurzanleitung

1. Offizielle Kodi-APK passend zur Gerätearchitektur installieren.
2. KODi.Debil-Dashboard.apk installieren und öffnen.
3. Im Dashboard `Kodi-Installer ZIP speichern` auswählen.
4. In Kodi die Installation aus unbekannten ZIP-Quellen erlauben.
5. `script.kodidebil.setup-1.0.0.zip` über Add-ons → Aus ZIP-Datei installieren.
6. Den KODi.Debil Profil-Installer unter Add-ons → Programm-Add-ons starten.
7. Die Sicherheitsabfrage bestätigen; vorhandene `favourites.xml` und `sources.xml` werden vorher gesichert.
8. Kodi vollständig neu starten.

Das Paket enthält zwei Kodi-APK-Architekturen, das Dashboard und zwei Profilpakete. Die Profil-ZIP ist auch manuell nutzbar. Sie enthält nur Favoriten und lokale Medienquellen.

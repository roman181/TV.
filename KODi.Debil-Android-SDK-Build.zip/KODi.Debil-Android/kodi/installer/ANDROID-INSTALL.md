# Installation auf Android – KODi.Debil Variante 1

## 1. Offizielle Kodi-App installieren

- Lade im GitHub-Release die passende offizielle Kodi-APK herunter:
  - `kodi-21.3-Omega-arm64-v8a.apk` für die meisten aktuellen Android-Geräte.
  - `kodi-21.3-Omega-armeabi-v7a.apk` für ältere 32-Bit-Geräte.
- Alternativ die offizielle Downloadseite öffnen: https://kodi.tv/download/android/
- Kodi einmal starten und die Erstinstallation abschließen.

## 2. Profil-Installer aus dem Dashboard exportieren

- KODi.Debil-Dashboard öffnen.
- `Kodi-Installer ZIP speichern` wählen und die Datei im Download-Ordner sichern.
- Kodi öffnen: Einstellungen → System → Add-ons → Unbekannte Quellen aktivieren.
- Add-ons → Aus ZIP-Datei installieren und `script.kodidebil.setup-1.0.0.zip` auswählen.
- Unter Meine Add-ons → Programm-Add-ons den `KODi.Debil Profil-Installer` starten.
- Die Installation bestätigen. Gleichnamige vorhandene Dateien werden vor dem Überschreiben in `userdata/KODi.Debil-Backups/` gesichert.
- Kodi vollständig beenden und neu starten.

## 3. Android-Speicherhinweis

Das Dashboard greift absichtlich nicht direkt auf `Android/data` zu. Android beschränkt diesen Ordner für andere Apps. Der Profil-Installer läuft innerhalb von Kodi und verwendet `special://userdata/`.

## 4. Profilinhalt und Grenzen

Das Starterprofil setzt Favoriten und lokale Medienquellen. Es installiert keine Drittanbieter-Add-ons, IPTV-Listen, Zugangsdaten, Cookies oder Caches. Medienquellen und Add-ons müssen separat geprüft und eingerichtet werden.

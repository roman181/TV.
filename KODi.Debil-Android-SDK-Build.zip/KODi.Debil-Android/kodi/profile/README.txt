KODi.Debil-Profil – Starter-Profil für Kodi 21 Omega

Das Paket enthält nur neutrale Kodi-Konfigurationen (Favoriten und lokale Medienquellen).
Es enthält keine Add-ons, Konten, Cookies, Tokens, Cache-Dateien oder persönlichen Daten.

Bevorzugte Installation:
1. KODi.Debil-Dashboard öffnen und „Kodi-Installer ZIP speichern“ wählen.
2. Kodi starten. Unter Einstellungen > System > Add-ons „Unbekannte Quellen“ aktivieren.
3. Add-ons > Aus ZIP-Datei installieren und script.kodidebil.setup-1.0.0.zip auswählen.
4. Unter Meine Add-ons > Programm-Add-ons den „KODi.Debil Profil-Installer“ starten.
5. Die Rückfrage bestätigen. Vorhandene gleichnamige Dateien werden vorher gesichert.
6. Kodi vollständig neu starten.

Alternativ kann userdata/ manuell in den Kodi-Userdata-Ordner kopiert werden.
Android-Pfad (typisch): Android/data/org.xbmc.kodi/files/.kodi/userdata/

Das Profil ist ein Startpunkt. Add-ons und Medienquellen müssen separat und nur aus
vertrauenswürdigen Quellen eingerichtet werden.

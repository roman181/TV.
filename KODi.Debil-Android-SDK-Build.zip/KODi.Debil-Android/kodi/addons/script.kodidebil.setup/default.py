# -*- coding: utf-8 -*-
"""KODi.Debil profile installer for Kodi 21 Omega.

Uses Kodi's own Python runtime and special://userdata, so the companion
Dashboard does not need Android/data filesystem access.
"""
import os
import shutil
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo("name")
ADDON_PATH = ADDON.getAddonInfo("path")


def translate(path):
    try:
        return xbmcvfs.translatePath(path)
    except Exception:
        return xbmc.translatePath(path)


PROFILE_SOURCE = os.path.join(translate(ADDON_PATH), "resources", "profile", "userdata")


def collect_files(root):
    result = []
    for current, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d.lower() not in ("cache", "cookies", "htmlcache")]
        for filename in files:
            result.append(os.path.join(current, filename))
    return result


def install_profile():
    dialog = xbmcgui.Dialog()
    userdata = os.path.abspath(translate("special://userdata/"))

    if not os.path.isdir(PROFILE_SOURCE):
        dialog.ok(ADDON_NAME, "Die eingebauten Profil-Dateien wurden nicht gefunden.")
        return

    files = collect_files(PROFILE_SOURCE)
    if not files:
        dialog.ok(ADDON_NAME, "Das Profil enthält keine Dateien.")
        return

    message = (
        "%d Konfigurationsdatei(en) werden installiert.\n\n"
        "Vorhandene gleichnamige Dateien werden zuerst in\n"
        "KODi.Debil-Backups gesichert.\n\nFortfahren?" % len(files)
    )
    if not dialog.yesno(ADDON_NAME, message):
        return

    stamp = time.strftime("%Y%m%d-%H%M%S")
    backup_root = os.path.join(userdata, "KODi.Debil-Backups", stamp)
    copied = 0
    backed_up = 0

    try:
        for source_file in files:
            relative = os.path.relpath(source_file, PROFILE_SOURCE)
            target_file = os.path.normpath(os.path.join(userdata, relative))
            if not target_file.startswith(userdata + os.sep):
                raise RuntimeError("Ungültiger Profilpfad: " + relative)

            parent = os.path.dirname(target_file)
            if not os.path.isdir(parent):
                os.makedirs(parent)

            if os.path.isfile(target_file):
                backup_file = os.path.join(backup_root, relative)
                backup_parent = os.path.dirname(backup_file)
                if not os.path.isdir(backup_parent):
                    os.makedirs(backup_parent)
                shutil.copy2(target_file, backup_file)
                backed_up += 1

            shutil.copy2(source_file, target_file)
            copied += 1

    except Exception as exc:
        dialog.ok(
            ADDON_NAME,
            "Installation wurde unterbrochen.\n%s\n\n%d Datei(en) kopiert; bitte Kodi prüfen."
            % (str(exc), copied),
        )
        return

    backup_note = "Sicherung: %s" % backup_root if backed_up else "Es waren keine Dateien zu sichern."
    success_message = (
        "KODi.Debil-Profil installiert.\n"
        "%d Datei(en) kopiert.\n" % copied
        + "%d vorhandene Datei(en) gesichert.\n" % backed_up
        + backup_note + "\nBitte Kodi vollständig neu starten."
    )
    dialog.ok(ADDON_NAME, success_message)


install_profile()
